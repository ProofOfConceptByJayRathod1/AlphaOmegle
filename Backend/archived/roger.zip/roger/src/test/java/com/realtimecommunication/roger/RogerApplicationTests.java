package com.realtimecommunication.roger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RogerApplicationTests {

	@Test
	void contextLoads() {
	}

}
