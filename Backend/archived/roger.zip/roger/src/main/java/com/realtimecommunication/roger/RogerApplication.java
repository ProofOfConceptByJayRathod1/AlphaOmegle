package com.realtimecommunication.roger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RogerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RogerApplication.class, args);
	}

}
